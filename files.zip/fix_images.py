"""
fix_images.py
=============
يقرأ كل ملف .md في public/content/articles/
إذا featured_image = null:
  1. يبحث عن أول صورة (blogger أو unsplash) داخل body المقال
  2. إن وجد → يضعها في featured_image
  3. إن لم يجد → يضع صورة Unsplash مناسبة للـ category

لا يمس أي شيء آخر في الملف.
"""

import os, re, sys

# صور Unsplash احتياطية حسب الـ category
FALLBACK_IMAGES = {
    "Screenshots & Screen Capture": "https://images.unsplash.com/photo-1607706189992-eae578626c86?auto=format&fit=crop&q=80&w=1200",
    "Redirect & Navigation":        "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1200",
    "Performance & Memory":         "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=1200",
    "Appearance & Themes":          "https://images.unsplash.com/photo-1550439062-609e1531270e?auto=format&fit=crop&q=80&w=1200",
    "Productivity & Tools":         "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&q=80&w=1200",
    "Security & Privacy":           "https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&q=80&w=1200",
    "General":                      "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&q=80&w=1200",
    "Utility":                      "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&q=80&w=1200",
    "default":                      "https://images.unsplash.com/photo-1607706189992-eae578626c86?auto=format&fit=crop&q=80&w=1200",
}

def extract_first_image_from_body(body: str) -> str | None:
    """يستخرج أول رابط صورة من داخل body المقال"""
    patterns = [
        r'<img[^>]+src=["\']([^"\'>\s]+)["\']',
        r'!\[.*?\]\((https?://[^\)]+)\)',
        r'src=["\'](["\']https?://[^\s"\'<>]+)',
    ]
    for pattern in patterns:
        matches = re.findall(pattern, body, re.IGNORECASE)
        for m in matches:
            # نتجاهل أيقونات Chrome Web Store
            if 'chromewebstore' not in m and m.startswith('http'):
                return m.strip()
    return None

def get_category_from_frontmatter(frontmatter: str) -> str:
    """يستخرج الـ category من الـ frontmatter"""
    m = re.search(r'^category:\s*(.+)$', frontmatter, re.MULTILINE)
    if m:
        return m.group(1).strip().strip('"\'')
    return "default"

def fix_md_file(filepath: str) -> str:
    """
    يُصلح ملف .md واحد.
    يرجع: "fixed_body", "fixed_fallback", "already_set", "skipped"
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # تأكد أن الملف فيه frontmatter
    if not content.startswith('---'):
        return "skipped"

    # قسّم الملف إلى frontmatter + body
    parts = content.split('---', 2)
    if len(parts) < 3:
        return "skipped"

    _, frontmatter, body = parts

    # إذا featured_image موجودة وليست null → لا تمس
    fm_check = re.search(r'^featured_image:\s*(.+)$', frontmatter, re.MULTILINE)
    if fm_check:
        val = fm_check.group(1).strip().strip('"\'')
        if val and val.lower() != 'null':
            return "already_set"

    # ابحث عن صورة في body
    image_url = extract_first_image_from_body(body)
    source = "body"

    if not image_url:
        # استخدم صورة fallback حسب الـ category
        category = get_category_from_frontmatter(frontmatter)
        image_url = FALLBACK_IMAGES.get(category, FALLBACK_IMAGES["default"])
        source = "fallback"

    # استبدل featured_image: null بالرابط الجديد
    new_frontmatter = re.sub(
        r'^(featured_image:\s*)null\s*$',
        f'featured_image: "{image_url}"',
        frontmatter,
        flags=re.MULTILINE
    )

    # إذا لم يكن featured_image موجوداً أصلاً، أضفه
    if new_frontmatter == frontmatter:
        new_frontmatter = frontmatter.rstrip() + f'\nfeatured_image: "{image_url}"\n'

    new_content = f'---{new_frontmatter}---{body}'

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)

    return f"fixed_{source}"


def main():
    base_dir = "public/content/articles"
    
    if not os.path.exists(base_dir):
        print(f"❌ المجلد غير موجود: {base_dir}")
        print("   تأكد أنك تشغل السكريبت من داخل مجلد المشروع")
        sys.exit(1)

    results = {
        "fixed_body":     [],
        "fixed_fallback": [],
        "already_set":    [],
        "skipped":        [],
    }

    md_files = []
    for root, dirs, files in os.walk(base_dir):
        for f in files:
            if f.endswith('.md'):
                md_files.append(os.path.join(root, f))

    if not md_files:
        print("❌ لم يتم العثور على أي ملفات .md")
        sys.exit(1)

    print(f"🔍 تم العثور على {len(md_files)} ملف .md\n")

    for fp in md_files:
        result = fix_md_file(fp)
        results[result].append(fp)
        
        if result == "fixed_body":
            print(f"✅ [صورة من المقال]   {os.path.basename(fp)}")
        elif result == "fixed_fallback":
            print(f"🖼️  [صورة احتياطية]   {os.path.basename(fp)}")
        elif result == "already_set":
            print(f"⏭️  [موجودة مسبقاً]   {os.path.basename(fp)}")
        else:
            print(f"⚠️  [تخطي]            {os.path.basename(fp)}")

    print("\n" + "="*50)
    print("📊 ملخص النتائج:")
    print(f"  ✅ تم إصلاحها (صورة من المقال):  {len(results['fixed_body'])}")
    print(f"  🖼️  تم إصلاحها (صورة احتياطية): {len(results['fixed_fallback'])}")
    print(f"  ⏭️  كانت موجودة مسبقاً:           {len(results['already_set'])}")
    print(f"  ⚠️  تم تخطيها:                    {len(results['skipped'])}")
    print(f"\n  📁 إجمالي الملفات المعالجة: {len(md_files)}")
    print("="*50)
    print("\n✨ تم الانتهاء! الآن ارفع الملفات المُصلَحة على GitHub.")


if __name__ == "__main__":
    main()
